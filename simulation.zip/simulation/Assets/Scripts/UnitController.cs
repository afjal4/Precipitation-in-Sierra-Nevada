﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitController : MonoBehaviour
{
    public GridController gridController;
    public GameObject unitPrefab;
    public int numUnitsPerSpawn;
    public float moveSpeed;
    public float trailUpdateInterval = 0.1f;

    private List<GameObject> unitsInGame;

	private void Awake()
	{
		unitsInGame = new List<GameObject>();
	}

	void Update()
	{
		if (Input.GetKeyDown(KeyCode.Alpha1))
		{
			SpawnUnits();
		}

		if (Input.GetKeyDown(KeyCode.Alpha2))
		{
			DestroyUnits();
		}
	}

	private void FixedUpdate()
	{
		if (gridController.curFlowField == null) { return; }
		foreach (GameObject unit in unitsInGame)
		{
			List<Vector3> positions = new List<Vector3>();
			Vector3 currentPos = unit.transform.position;
			positions.Add(currentPos);

			// Predict and draw the path
			for (int i = 0; i < 10; i++)
			{
				Cell cellBelow = gridController.curFlowField.GetCellFromWorldPos(currentPos);
				Vector3 moveDirection = new Vector3(cellBelow.bestDirection.Vector.x, 0, cellBelow.bestDirection.Vector.y);
				currentPos += moveDirection * moveSpeed * Time.fixedDeltaTime;
				positions.Add(currentPos);
			}


			// Move the unit
			Cell currentCell = gridController.curFlowField.GetCellFromWorldPos(unit.transform.position);
			Vector3 moveDir = new Vector3(currentCell.bestDirection.Vector.x, 0, currentCell.bestDirection.Vector.y);
			Rigidbody unitRB = unit.GetComponent<Rigidbody>();	
			unitRB.linearVelocity = moveDir * moveSpeed;
		}
	}

	private void SpawnUnits()
	{
		Debug.Log("Spawn Units");
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit hit;
		int groundMask = LayerMask.GetMask("Default");
		if (Physics.Raycast(ray, out hit, Mathf.Infinity, groundMask))
		{
			GameObject newUnit = Instantiate(unitPrefab);
			newUnit.transform.parent = transform;
			newUnit.transform.localScale *= 5f;
			newUnit.transform.position = hit.point;
				
			// Replace the trail setup with:
			TrailRenderer trailRenderer = newUnit.AddComponent<TrailRenderer>();
			trailRenderer.startWidth = 0.1f;
			trailRenderer.endWidth = 0.05f;
			trailRenderer.minVertexDistance = 0.1f; // Minimum distance between points
			trailRenderer.material = new Material(Shader.Find("Sprites/Default"));
			trailRenderer.startColor = Color.red;
			
			unitsInGame.Add(newUnit);
			Collider unitCollider = newUnit.GetComponent<Collider>();
			unitCollider.enabled = false;
		}
	}

	private void DestroyUnits()
	{
		foreach (GameObject go in unitsInGame)
		{
			Destroy(go);
		}
		unitsInGame.Clear();
	}

	private void Start()
	{
		// Create a marker cube at the start position
		GameObject startMarker = GameObject.CreatePrimitive(PrimitiveType.Cube);
		startMarker.transform.parent = transform;
		startMarker.transform.position = new Vector3(170f, 0f, 170f);
		startMarker.transform.localScale = new Vector3(5f, 1f, 5f);
		startMarker.GetComponent<Renderer>().material.color = Color.green;

		// Spawn a single unit at (170, 170)
		GameObject newUnit = Instantiate(unitPrefab);
		newUnit.transform.parent = transform;
		newUnit.transform.localScale *= 5f;
		newUnit.transform.position = new Vector3(170f, 0f, 170f);
		
		
		// Replace the trail setup with:
		TrailRenderer trailRenderer = newUnit.AddComponent<TrailRenderer>();
		trailRenderer.startWidth = 2f;
		trailRenderer.endWidth = 2f;
		trailRenderer.time = float.MaxValue;
		trailRenderer.minVertexDistance = 0.1f; // Minimum distance between points
		trailRenderer.material = new Material(Shader.Find("Sprites/Default"));
		trailRenderer.startColor = Color.red;
		
		unitsInGame.Add(newUnit);
		Collider unitCollider = newUnit.GetComponent<Collider>();
		unitCollider.enabled = false;
	}
}
