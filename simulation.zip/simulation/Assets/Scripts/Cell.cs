﻿using UnityEngine;

public class Cell
{
	public Vector3 worldPos;
	public Vector2Int gridIndex;
	public int cost;
	public int bestCost;
	public GridDirection bestDirection;
	public float height;

	public Cell(Vector3 _worldPos, Vector2Int _gridIndex)
	{
		worldPos = _worldPos;
		gridIndex = _gridIndex;
		cost = 1;
		bestCost = int.MaxValue;
		bestDirection = GridDirection.None;
	}

	public void IncreaseCost(int amnt)
	{
		if (cost == int.MaxValue) { return; }
		if (amnt + cost >= int.MaxValue) { cost = int.MaxValue; }
		else { cost += amnt; }
	}
}