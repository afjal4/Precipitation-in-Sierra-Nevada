﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridController : MonoBehaviour
{
    public Vector2Int gridSize;
    public float cellRadius = 0.5f;
    public FlowField curFlowField;
	public GridDebug gridDebug;

    private void InitializeFlowField()
	{
        curFlowField = new FlowField(cellRadius, gridSize);
        curFlowField.CreateGrid();
		gridDebug.SetFlowField(curFlowField);
	}
	private void Start()
	{
		InitializeFlowField();
		curFlowField.CreateCostField();
		// set a destination cell at 50 50	
		Vector3 destinationPos = new Vector3(50, 0, 50);
		Cell destinationCell = curFlowField.GetCellFromWorldPos(destinationPos);
		Debug.Log(destinationCell.gridIndex);
		curFlowField.CreateIntegrationField(destinationCell);
		curFlowField.CreateFlowField();

		gridDebug.DrawFlowField();
		

		GameObject endMarker = GameObject.CreatePrimitive(PrimitiveType.Cube);
		endMarker.transform.parent = transform;
		endMarker.transform.position = new Vector3(50f, 0f, 50f);
		endMarker.transform.localScale = new Vector3(5f, 1f, 5f);
		endMarker.GetComponent<Renderer>().material.color = Color.red;
	}

	private void Update()
	{
		// if (Input.GetMouseButtonDown(0))
		// {
		// }
	}
}
