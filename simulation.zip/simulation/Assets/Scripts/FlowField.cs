﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlowField
{
	public Cell[,] grid { get; private set; }
	public Vector2Int gridSize { get; private set; }
	public float cellRadius { get; private set; }
	public Cell destinationCell;

	private float cellDiameter;

	public FlowField(float _cellRadius, Vector2Int _gridSize)
	{
		cellRadius = _cellRadius;
		cellDiameter = cellRadius * 2f;
		gridSize = _gridSize;
	}

	public void CreateGrid()
	{
		grid = new Cell[240, 240];
		
		// Read the CSV file
		string[] lines = System.IO.File.ReadAllLines("tiff_data.csv");
		for (int x = 0; x< lines.Length; x++)
		{
			string[] values = lines[x].Split(',');
			Vector2Int position = new Vector2Int(int.Parse(values[0]), int.Parse(values[1]));
			Cell cell = new Cell(new Vector3(cellDiameter * position.x + cellRadius, 0, cellDiameter * position.y + cellRadius), position);
			cell.height = float.Parse(values[2]);
			grid[position.x, position.y] = cell;
		}
		Debug.Log("Grid created");
	}

	public void CreateCostField()
	{
		foreach (Cell curCell in grid)
		{
			List<Cell> neighbors = GetNeighborCells(curCell.gridIndex, GridDirection.CardinalDirections);
			float maxHeightDifference = 0f;
			foreach (Cell neighbor in neighbors)
			{
				float heightDifference = Mathf.Abs(curCell.height - neighbor.height);
				maxHeightDifference = Mathf.Max(maxHeightDifference, heightDifference);
			}
			curCell.cost = Mathf.RoundToInt(maxHeightDifference);
		}
	}

	public void CreateIntegrationField(Cell _destinationCell)
	{
		destinationCell = _destinationCell;

		destinationCell.cost = 0;
		destinationCell.bestCost = 0;

		Queue<Cell> cellsToCheck = new Queue<Cell>();

		cellsToCheck.Enqueue(destinationCell);

		while(cellsToCheck.Count > 0)
		{
			Cell curCell = cellsToCheck.Dequeue();
			List<Cell> curNeighbors = GetNeighborCells(curCell.gridIndex, GridDirection.CardinalDirections);
			foreach (Cell curNeighbor in curNeighbors)
			{
				float heightDifference = Mathf.Abs(curCell.height - curNeighbor.height);
				int heightCost = Mathf.RoundToInt(heightDifference);
				int totalCost = curNeighbor.cost + heightCost;
				
				if (totalCost + curCell.bestCost < curNeighbor.bestCost && totalCost + curCell.bestCost < int.MaxValue)
				{
					curNeighbor.bestCost = totalCost + curCell.bestCost;
					cellsToCheck.Enqueue(curNeighbor);
				}
			}
		}
	}

	public void CreateFlowField()
	{

		foreach(Cell curCell in grid)
		{
			List<Cell> curNeighbors = GetNeighborCells(curCell.gridIndex, GridDirection.AllDirections);

			int bestCost = curCell.bestCost;

			foreach(Cell curNeighbor in curNeighbors)
			{
				if(curNeighbor.bestCost < bestCost)
				{
					bestCost = curNeighbor.bestCost;
					curCell.bestDirection = GridDirection.GetDirectionFromV2I(curNeighbor.gridIndex - curCell.gridIndex);
				}
			}
		}
	}

	private List<Cell> GetNeighborCells(Vector2Int nodeIndex, List<GridDirection> directions)
	{
		List<Cell> neighborCells = new List<Cell>();

		foreach (Vector2Int curDirection in directions)
		{
			Cell newNeighbor = GetCellAtRelativePos(nodeIndex, curDirection);
			if (newNeighbor != null)
			{
				neighborCells.Add(newNeighbor);
			}
		}
		return neighborCells;
	}

	private Cell GetCellAtRelativePos(Vector2Int orignPos, Vector2Int relativePos)
	{
		Vector2Int finalPos = orignPos + relativePos;

		if (finalPos.x < 0 || finalPos.x >= gridSize.x || finalPos.y < 0 || finalPos.y >= gridSize.y)
		{
			return null;
		}

		else { return grid[finalPos.x, finalPos.y]; }
	}

	public Cell GetCellFromWorldPos(Vector3 worldPos)
	{
		float percentX = worldPos.x / (gridSize.x * cellDiameter);
		float percentY = worldPos.z / (gridSize.y * cellDiameter);

		percentX = Mathf.Clamp01(percentX);
		percentY = Mathf.Clamp01(percentY);

		int x = Mathf.Clamp(Mathf.FloorToInt((gridSize.x) * percentX), 0, gridSize.x - 1);
		int y = Mathf.Clamp(Mathf.FloorToInt((gridSize.y) * percentY), 0, gridSize.y - 1);
		return grid[x, y];
	}
}
